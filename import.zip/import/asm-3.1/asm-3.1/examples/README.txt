This directory contains the examples of the product. 
It contains(*) the following items:

- lib: jar files shared by all examples,
- etc: configuration files shared by all examples,
- README.txt: explains the organisation of the examples directory,
- all other directories contain(*) the following items:
  - README.txt file: describes the example and its configuration,
  - lib: jar files needed by the example,
  - etc: configuration files needed by the example,
  - src: source code of the example.

(*) some items may not be present, depending on the product or example.